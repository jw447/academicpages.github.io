---
layout: archive
title: "Teaching"
permalink: /teaching/
author_profile: true
---

{% include base_path %}

## Spring 2019
### ECE394 Digital Systems Lab

Schedule: Wednesday 6:00 - 8:50pm, Jan 22nd - May 16th;<br/>
Venue: LSEC 302A

Office hour: Wednesday 5:00 - 6:00pm, Jan 22nd - May 16th;<br/>
Venue: FMH 105

## Fall 2018
### ECE394 Digital Systems Lab

Schedule: Monday 1:00 - 3:50pm, Sep 04th - Dec 10th;<br/>
Venue: LSEC 302B

Office hour: Monday 4:00 - 5:00pm, Sep 04th - Dec 10th;<br/>
Venue: FMH 105

---

<div>
	<iframe src="https://calendar.google.com/calendar/embed?title=Calender&amp;height=300&amp;wkst=2&amp;bgcolor=%23ffffff&amp;src=njit.edu_ghtq7q178tvrr0i0v4g9e1jfek%40group.calendar.google.com&amp;color=%23853104&amp;ctz=America%2FNew_York" style="border-width:0" width="600" height="450" frameborder="0" scrolling="no"></iframe>
</div>
