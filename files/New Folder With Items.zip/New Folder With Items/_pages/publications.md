---
layout: archive
title: "Publications"
permalink: /publications/
author_profile: true
---

{% include base_path %}

Luo, H., Liu, Q., Qiao, Z., Wang, J., Wang, M., & Jiang, H. (2018). DuoModel: Leveraging Reduced Model for Data Reduction and Re-Computation on HPC Storage. IEEE Letters of the Computer Society, 1(1), 5-8.

Qiao, Z., Lu, T., Luo, H., Liu, Q., Klasky, S., Podhorszki, N., & Wang, J. (2018). SIRIUS: Enabling Progressive Data Exploration for Extreme-Scale Scientific Data. IEEE Transactions on Multi-Scale Computing Systems.
